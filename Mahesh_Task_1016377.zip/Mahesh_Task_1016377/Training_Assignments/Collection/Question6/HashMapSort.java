package com.yash.collectionDemo.Question6;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

public class HashMapSort {
	public static void main(String[] args) {
		TreeMap<String, Integer> map=new TreeMap<>();
		map.put("wardha", 11000000);
		map.put("yavatmal", 13400000);
		map.put("amravati", 189000000);
		map.put("jalgaon", 14560000);
		
		System.out.println(map);
	}
	
}
