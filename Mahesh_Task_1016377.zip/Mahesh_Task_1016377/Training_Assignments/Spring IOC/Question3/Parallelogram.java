package com.yash.ioc.Question3;

public class Parallelogram extends Shape {

	@Override
	public void draw() {
		System.out.println("display method executed from Parallelogram ");
	}

}
