package com.yash.exceptions.Question8;

public class PasswordException extends Exception{

	 public PasswordException(String message) {
	        super(message);
	    }
}
