package com.yash.exceptions.Question10;

public class Pilot {

	public static void main(String[] args) {

		int arr[] = { 4, 9, 3, 2, 5, 9, 7, 1 };
		Parent p = new Child();
		p.maximum(arr);

	}

}
