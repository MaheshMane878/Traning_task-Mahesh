package com.yash.exceptions.Question9;

public class CollarStandardDeviate extends Exception {
	public CollarStandardDeviate(String response) {
		super(response);
	}

}
