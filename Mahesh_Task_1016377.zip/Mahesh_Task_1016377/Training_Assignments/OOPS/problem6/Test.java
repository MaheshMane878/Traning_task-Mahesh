package com.yash.traning.opps.homeAssignemnt.problem6;

public class Test extends LargestNumberExample
{

	public static void main(String[] args)
	{
		LargestNumberExample l =new LargestNumberExample();
		                     l.LargestNumberOF3();
		                     l.LargestNumberOF4();
		                 
	}

}
