package com.yash.traning.opps.homeAssignemnt.problem5;

public class ClassD extends ClassC {

	@Override
	void div(int a, int b) {
		int c=a/b;
		System.out.println("Div of 2 digit :"+c);
	}
	
}
