package com.yash.traning.opps.homeAssignemnt.problem5;
public class CalcAbsDemo {

	public static void main(String[] args) {
		ClassD d1=new ClassD();
		d1.div(10, 2);
		d1.sub(40, 10);
		d1.mul(5, 5);
		d1.sum(30, 20);
	
}}
;