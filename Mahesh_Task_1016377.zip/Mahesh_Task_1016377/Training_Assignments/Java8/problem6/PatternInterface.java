package com.yash.java8.problem6;


public interface PatternInterface {
	
	 void displayPattern(int row);
}
