package com.yash.java8.problem3;

public interface Demo {
	void print();
}
