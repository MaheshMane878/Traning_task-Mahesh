package com.yash.java8.problem1;

public interface Check {
	 void print ();
}
