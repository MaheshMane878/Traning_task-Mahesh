package com.yash.TddExample.stringassignmenttwo;

public class MemberInfoMain {
	public static void main(String[] args) {
		MemberInfo mi=new MemberInfo();
		
		String minfo=mi.showMemberDetail();
		System.out.println(minfo);
	}

}
