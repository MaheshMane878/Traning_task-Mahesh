package com.yash.TddExample.stringassignmentthree;

public class SectionMain {
	public static void main(String[] args) {
		Section s=new Section();
		
		String sdeatil=s.showSectionDetail();
		System.out.println(sdeatil);
	}

}
